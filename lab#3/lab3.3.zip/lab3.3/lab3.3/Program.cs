﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace lab3._3
{
    class Program
    {
        static void Main(string[] args)
        {
            char C = 's';
            string str1 = "mercedes apple BMW Alibaba Amazon"; // consisits one
            string str2 = "mercedes apple BMW Alibaba Airpods"; // consisits two
            string str3 = "apple BMW Alibaba"; /// consisits none

            string[] arr = str1.Split(" ");
            List<string> list = new List<string>(arr);

            Console.WriteLine("Our string -> " + str1);

            int counter = 0;
            string element = "";
            foreach (var item in list)
            {
                if (item.Last() == C)
                {
                    counter++;
                    element = item;
                }
            }

            if (counter == 1)
            {
                Console.WriteLine(element);
            }
            else if (counter == 0)
            {
                Console.WriteLine("*Empty line, as there is no words ending with \"" + C + "\"*");
            }
            else
            {
                Console.WriteLine("Error");
            }
        }
    }
}
