﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab2._1.weapons
{
    // пулемет
    public class MachineGun : Weapon
    {
        public MachineGun() : base() { this.type = "Machine gun"; }
    }
}
