﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab2._1.weapons
{
    public class Pistol : Weapon
    {
        public Pistol() : base() { this.type = "Pistol"; }
    }
}
